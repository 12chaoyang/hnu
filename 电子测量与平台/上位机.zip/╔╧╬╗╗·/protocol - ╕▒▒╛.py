from __future__ import annotations

from dataclasses import dataclass


MIN_RATE_MS = 50
MAX_RATE_MS = 5000


@dataclass(frozen=True)
class Measurement:
    distance_cm: int
    state: str
    seq: int


def parse_raw_distance(value: int, seq: int) -> Measurement:
    if not (0 <= value <= 255):
        raise ValueError("raw distance byte must be 0-255")
    return Measurement(distance_cm=value, state="RUN", seq=seq)


def checksum_hex(payload: str) -> str:
    value = 0
    for char in payload:
        value ^= ord(char)
    return f"{value:02X}"


def parse_frame(line: str) -> Measurement | tuple[str, str]:
    text = line.strip()
    if not text.startswith("$") or "*" not in text:
        raise ValueError("frame must use $payload*checksum format")

    payload, checksum = text[1:].split("*", 1)
    checksum = checksum[:2].upper()
    if checksum_hex(payload) != checksum:
        raise ValueError("checksum mismatch")

    fields = payload.split(",")
    if not fields:
        raise ValueError("empty payload")

    frame_type = fields[0].upper()
    if frame_type == "D":
        if len(fields) != 4:
            raise ValueError("distance frame requires 4 fields")
        return Measurement(
            distance_cm=int(fields[1]),
            state=fields[2].upper(),
            seq=int(fields[3]),
        )

    if frame_type in {"ACK", "ERR"}:
        if len(fields) < 2:
            raise ValueError("status frame requires message")
        return frame_type, ",".join(fields[1:])

    raise ValueError(f"unknown frame type: {frame_type}")


def build_command(command: str, value: int | None = None) -> bytes:
    name = command.strip().upper()
    if name in {"START", "STOP", "PING"}:
        if value is not None:
            raise ValueError(f"{name} does not take a value")
        return f"{name}\n".encode("ascii")

    if name == "RATE":
        if value is None:
            raise ValueError("RATE requires a millisecond value")
        if not (MIN_RATE_MS <= value <= MAX_RATE_MS):
            raise ValueError(f"RATE must be {MIN_RATE_MS}-{MAX_RATE_MS} ms")
        return f"RATE={value}\n".encode("ascii")

    raise ValueError(f"unsupported command: {command}")
