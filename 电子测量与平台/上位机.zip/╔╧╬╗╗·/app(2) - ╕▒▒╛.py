from __future__ import annotations

import csv
import queue
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, X, Canvas, StringVar, Tk, filedialog, messagebox, ttk

import serial
from serial.tools import list_ports

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from protocol import Measurement, build_command, parse_frame, parse_raw_distance


BAUD_RATE = 115200
MAX_POINTS = 120
READ_TIMEOUT_S = 0.005
UI_REFRESH_MS = 16
MAX_EVENTS_PER_TICK = 500
MAX_TABLE_ROWS = 80
RAW_NO_DETECTION_VALUES = {0}
RAW_MAX_DISTANCE_CM = 250
RAW_JUMP_LIMIT_CM = 50
RAW_CONFIRM_COUNT = 2


@dataclass
class SampleLog:
    samples: list[tuple[float, Measurement]] = field(default_factory=list)

    def append(self, item: Measurement) -> None:
        self.samples.append((time.time(), item))

    def save_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(["timestamp", "distance_cm", "state", "seq"])
            for timestamp, item in self.samples:
                writer.writerow([
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp)),
                    item.distance_cm,
                    item.state,
                    item.seq,
                ])


class SerialWorker:
    def __init__(self, event_queue: queue.Queue[object]) -> None:
        self.event_queue = event_queue
        self.port: serial.Serial | None = None
        self.thread: threading.Thread | None = None
        self.running = False
        self.parse_mode = "raw"
        self.seq = 0
        self.last_raw_distance: int | None = None
        self.pending_raw_distance: int | None = None
        self.pending_raw_count = 0

    def open(self, port_name: str, parse_mode: str) -> None:
        self.close()
        self.parse_mode = parse_mode
        self.seq = 0
        self.last_raw_distance = None
        self.pending_raw_distance = None
        self.pending_raw_count = 0
        try:
            self.port = serial.Serial(
                port_name,
                BAUD_RATE,
                timeout=READ_TIMEOUT_S,
                write_timeout=0,
                dsrdtr=False,
                rtscts=False,
            )
            self.port.dtr = False
            self.port.rts = False
            self.port.reset_input_buffer()
            self.running = True
            self.thread = threading.Thread(target=self._read_loop, daemon=True)
            self.thread.start()
        except Exception:
            self.running = False
            self.port = None
            raise

    def close(self) -> None:
        self.running = False
        if self.port is not None:
            try:
                self.port.close()
            finally:
                self.port = None

    def send(self, command: str, value: int | None = None) -> None:
        if self.port is None or not self.port.is_open:
            raise RuntimeError("serial port is not open")
        self.port.write(build_command(command, value))

    def _read_loop(self) -> None:
        assert self.port is not None
        buffer = bytearray()

        while self.running and self.port is not None and self.port.is_open:
            try:
                waiting = self.port.in_waiting
                read_size = max(1, min(waiting, 256))
                chunk = self.port.read(read_size)
                if not chunk:
                    continue
                if self.parse_mode == "raw":
                    latest_value = None
                    for value in chunk:
                        accepted = self._filter_raw_distance(value)
                        if accepted is not None:
                            latest_value = accepted
                    if latest_value is not None:
                        self.seq += 1
                        self.event_queue.put(parse_raw_distance(latest_value, self.seq))
                else:
                    buffer.extend(chunk)
                    while b"\n" in buffer:
                        raw, _, rest = buffer.partition(b"\n")
                        buffer = bytearray(rest)
                        text = raw.decode("ascii", errors="ignore").strip()
                        if not text:
                            continue
                        try:
                            self.event_queue.put(parse_frame(text))
                        except ValueError as exc:
                            self.event_queue.put(f"Bad frame: {text} ({exc})")
            except serial.SerialException as exc:
                self.event_queue.put(f"Serial error: {exc}")
                self.running = False

    def _filter_raw_distance(self, value: int) -> int | None:
        if value in RAW_NO_DETECTION_VALUES or value > RAW_MAX_DISTANCE_CM:
            return None

        if self.last_raw_distance is None:
            self.last_raw_distance = value
            self.pending_raw_distance = None
            self.pending_raw_count = 0
            return value

        if abs(value - self.last_raw_distance) <= RAW_JUMP_LIMIT_CM:
            self.last_raw_distance = value
            self.pending_raw_distance = None
            self.pending_raw_count = 0
            return value

        if self.pending_raw_distance is not None and abs(value - self.pending_raw_distance) <= RAW_JUMP_LIMIT_CM:
            self.pending_raw_distance = value
            self.pending_raw_count += 1
            if self.pending_raw_count >= RAW_CONFIRM_COUNT:
                self.last_raw_distance = value
                self.pending_raw_distance = None
                self.pending_raw_count = 0
                return value
            return None

        self.pending_raw_distance = value
        self.pending_raw_count = 1
        return None


class ToFApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title("Cy4 ToF 蓝牙测距上位机")
        self.root.geometry("980x680")
        self.events: queue.Queue[object] = queue.Queue()
        self.worker = SerialWorker(self.events)
        self.log = SampleLog()
        self.distances: list[int] = []
        self.seq_values: list[int] = []

        self.port_var = StringVar()
        self.status_var = StringVar(value="未连接")
        self.distance_var = StringVar(value="-- cm")
        self.state_var = StringVar(value="STOP")
        self.rate_var = StringVar(value="200")
        self.protocol_var = StringVar(value="原始字节")

        self._build_ui()
        self.refresh_ports()
        self._set_connected(False)
        self.root.after(UI_REFRESH_MS, self._poll_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self) -> None:
        top = ttk.Frame(self.root, padding=10)
        top.pack(fill=X)

        ttk.Label(top, text="COM口").pack(side=LEFT)
        self.port_combo = ttk.Combobox(top, textvariable=self.port_var, width=24)
        self.port_combo.pack(side=LEFT, padx=6)
        ttk.Button(top, text="刷新", command=self.refresh_ports).pack(side=LEFT)
        ttk.Label(top, text="协议").pack(side=LEFT, padx=(12, 4))
        self.protocol_combo = ttk.Combobox(
            top,
            textvariable=self.protocol_var,
            values=("原始字节", "文本帧"),
            width=10,
            state="readonly",
        )
        self.protocol_combo.pack(side=LEFT)
        self.connect_button = ttk.Button(top, text="连接", command=self.connect)
        self.connect_button.pack(side=LEFT, padx=(12, 4))
        self.disconnect_button = ttk.Button(top, text="断开", command=self.disconnect)
        self.disconnect_button.pack(side=LEFT)
        ttk.Label(top, textvariable=self.status_var).pack(side=RIGHT)

        controls = ttk.Frame(self.root, padding=(10, 0, 10, 8))
        controls.pack(fill=X)
        self.start_button = ttk.Button(controls, text="START", command=lambda: self.send("START"))
        self.start_button.pack(side=LEFT)
        self.stop_button = ttk.Button(controls, text="STOP", command=lambda: self.send("STOP"))
        self.stop_button.pack(side=LEFT, padx=6)
        self.ping_button = ttk.Button(controls, text="PING", command=lambda: self.send("PING"))
        self.ping_button.pack(side=LEFT)
        ttk.Label(controls, text="测量周期 ms").pack(side=LEFT, padx=(20, 4))
        ttk.Entry(controls, textvariable=self.rate_var, width=8).pack(side=LEFT)
        self.rate_button = ttk.Button(controls, text="设置", command=self.set_rate)
        self.rate_button.pack(side=LEFT, padx=6)
        ttk.Button(controls, text="保存CSV", command=self.save_csv).pack(side=RIGHT)

        main = ttk.Frame(self.root, padding=10)
        main.pack(fill=BOTH, expand=True)

        left_panel = ttk.Frame(main)
        left_panel.pack(side=LEFT, fill=BOTH)
        ttk.Label(left_panel, text="实时距离", font=("Microsoft YaHei UI", 18, "bold")).pack(anchor="w")
        ttk.Label(left_panel, textvariable=self.distance_var, font=("Consolas", 34, "bold")).pack(anchor="w", pady=(4, 12))
        ttk.Label(left_panel, text="状态").pack(anchor="w")
        ttk.Label(left_panel, textvariable=self.state_var, font=("Consolas", 20)).pack(anchor="w", pady=(0, 10))
        self.gauge = Canvas(left_panel, width=300, height=260, bg="white", highlightthickness=1, highlightbackground="#d0d7de")
        self.gauge.pack()
        self._draw_gauge(None)

        right_panel = ttk.Frame(main)
        right_panel.pack(side=RIGHT, fill=BOTH, expand=True, padx=(16, 0))
        fig = Figure(figsize=(6.2, 4.4), dpi=100)
        self.ax = fig.add_subplot(111)
        self.ax.set_title("Distance History")
        self.ax.set_xlabel("sample")
        self.ax.set_ylabel("cm")
        self.ax.grid(True, alpha=0.3)
        self.line, = self.ax.plot([], [], color="#1f77b4", linewidth=2)
        self.chart = FigureCanvasTkAgg(fig, right_panel)
        self.chart.get_tk_widget().pack(fill=BOTH, expand=True)

        self.log_box = ttk.Treeview(right_panel, columns=("seq", "distance", "state"), show="headings", height=8)
        self.log_box.heading("seq", text="Seq")
        self.log_box.heading("distance", text="Distance/cm")
        self.log_box.heading("state", text="State")
        self.log_box.column("seq", width=80, anchor="center")
        self.log_box.column("distance", width=120, anchor="center")
        self.log_box.column("state", width=100, anchor="center")
        self.log_box.pack(fill=X, pady=(10, 0))

    def refresh_ports(self) -> None:
        ports = [port.device for port in list_ports.comports()]
        current = self.port_var.get().strip()
        if current and current.upper() not in {port.upper() for port in ports}:
            ports.insert(0, current.upper())
        elif "COM11" not in ports:
            ports.insert(0, "COM11")
        self.port_combo["values"] = ports
        if "COM11" in ports:
            self.port_var.set("COM11")
        elif ports and not self.port_var.get():
            self.port_var.set(ports[0])

    def connect(self) -> None:
        port_name = self.port_var.get().strip().upper()
        if not port_name:
            messagebox.showwarning("COM口", "未发现串口。请先配对 HC-05 或插入 USB-TTL。")
            return
        try:
            parse_mode = "text" if self.protocol_var.get() == "文本帧" else "raw"
            self.worker.open(port_name, parse_mode)
            mode_text = "文本帧" if parse_mode == "text" else "原始字节"
            self.status_var.set(f"已连接 {port_name} @ {BAUD_RATE}，{mode_text}")
            self._set_connected(True)
        except serial.SerialException as exc:
            self._set_connected(False)
            messagebox.showerror("连接失败", self._format_serial_error(port_name, exc))

    def disconnect(self) -> None:
        self.worker.close()
        self.status_var.set("未连接")
        self._set_connected(False)

    def send(self, command: str) -> None:
        if self.worker.port is None or not self.worker.port.is_open:
            messagebox.showwarning("未连接", "请先点击“连接”，右上角显示“已连接”后再发送命令。")
            return
        try:
            self.worker.send(command)
        except Exception as exc:
            messagebox.showerror("发送失败", str(exc))

    def set_rate(self) -> None:
        if self.worker.port is None or not self.worker.port.is_open:
            messagebox.showwarning("未连接", "请先点击“连接”，右上角显示“已连接”后再设置周期。")
            return
        try:
            self.worker.send("RATE", int(self.rate_var.get()))
        except Exception as exc:
            messagebox.showerror("设置失败", str(exc))

    def save_csv(self) -> None:
        path = filedialog.asksaveasfilename(
            title="保存历史数据",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.log.save_csv(Path(path))
            messagebox.showinfo("已保存", path)

    def _poll_events(self) -> None:
        latest_measurement: Measurement | None = None
        latest_rows: list[Measurement] = []
        processed = 0

        while processed < MAX_EVENTS_PER_TICK:
            try:
                item = self.events.get_nowait()
            except queue.Empty:
                break
            processed += 1

            if isinstance(item, Measurement):
                self._append_measurement(item)
                latest_measurement = item
                latest_rows.append(item)
            elif isinstance(item, tuple) and len(item) == 2:
                self.status_var.set(f"{item[0]}: {item[1]}")
            else:
                self.status_var.set(str(item))
                if str(item).startswith("Serial error:"):
                    self._set_connected(False)

        if latest_measurement is not None:
            self._render_measurement(latest_measurement)
            for item in latest_rows[-12:]:
                self.log_box.insert("", 0, values=(item.seq, item.distance_cm, item.state))
            for child in self.log_box.get_children()[MAX_TABLE_ROWS:]:
                self.log_box.delete(child)

        if processed == MAX_EVENTS_PER_TICK and not self.events.empty():
            self.root.after(1, self._poll_events)
        else:
            self.root.after(UI_REFRESH_MS, self._poll_events)

    def _set_connected(self, connected: bool) -> None:
        command_state = "normal" if connected else "disabled"
        for button in (self.start_button, self.stop_button, self.ping_button, self.rate_button):
            button.configure(state=command_state)
        self.connect_button.configure(state="disabled" if connected else "normal")
        self.disconnect_button.configure(state="normal" if connected else "disabled")

    def _format_serial_error(self, port_name: str, exc: serial.SerialException) -> str:
        return (
            f"无法打开 {port_name}。\n\n"
            f"底层错误：{exc}\n\n"
            "处理建议：\n"
            "1. 关闭 STC-ISP、串口助手等正在使用该端口的软件；Windows 串口通常只能被一个程序独占。\n"
            "2. 在 Windows 设备管理器或蓝牙 COM 端口里确认当前传出端口号。\n"
            "3. 点击“刷新”，或直接在 COM 口输入框里输入 COM11 后再连接。"
        )

    def _append_measurement(self, item: Measurement) -> None:
        self.log.append(item)
        self.distances.append(item.distance_cm)
        self.seq_values.append(item.seq)
        self.distances = self.distances[-MAX_POINTS:]
        self.seq_values = self.seq_values[-MAX_POINTS:]

    def _render_measurement(self, item: Measurement) -> None:
        self.distance_var.set(f"{item.distance_cm} cm")
        self.state_var.set(item.state)
        self.line.set_data(range(len(self.distances)), self.distances)
        self.ax.set_xlim(0, max(10, len(self.distances)))
        max_y = max(50, max(self.distances, default=50) + 20)
        self.ax.set_ylim(0, max_y)
        self.chart.draw_idle()
        self._draw_gauge(item.distance_cm)

    def _draw_gauge(self, distance: int | None) -> None:
        self.gauge.delete("all")
        self.gauge.create_arc(35, 45, 265, 275, start=0, extent=180, style="arc", width=18, outline="#d0d7de")
        value = 0 if distance is None else max(0, min(distance, 400))
        extent = int(180 * value / 400)
        color = "#d62728" if value < 30 else "#ff7f0e" if value < 80 else "#2ca02c"
        self.gauge.create_arc(35, 45, 265, 275, start=180 - extent, extent=extent, style="arc", width=18, outline=color)
        self.gauge.create_text(150, 160, text="--" if distance is None else str(distance), font=("Consolas", 38, "bold"), fill=color)
        self.gauge.create_text(150, 205, text="cm", font=("Microsoft YaHei UI", 15), fill="#57606a")
        self.gauge.create_text(50, 230, text="0", fill="#57606a")
        self.gauge.create_text(250, 230, text="400", fill="#57606a")

    def _on_close(self) -> None:
        self.worker.close()
        self.root.destroy()


def main() -> None:
    root = Tk()
    ToFApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
